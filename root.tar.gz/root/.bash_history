history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ip a
apt update
clear
ip link set enp0s1 up
dhclient enp0s1
ip a
apt update
clear
apt install -y kbd
loadkeys us
apt install -y openssh-server
sed -i "$ a PermitRootLogin yes" /etc/ssh/sshd_config
systemctl restart ssh 
clear
app install -y nano
atp install -y nano
apt install -y nano
nano /etc/apt/sources.list
clear
apt update
apt upgrade -y
clear
apt full-upgrade -y  
reboot
cat /etc/os-release
ip link set enp0s1 up
dhclient enp0s1
ip a
echo "127.0.1.1   TPServer" >> /etc/hosts
cd ~/Downloads/TPVM
clear
mkdir -p /root/.ssh
cat /root/clave_publica.pub > /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
clear
apt install -y apache2 php libapache2-mod-php php-mysql mariadb-server
cp /root/index.php /var/www/html/
mysql < /root/db.sql
systemctl restart apache2
systemctl is-active apache2 mariadb
mysql -e "SHOW DATABASES;"
mysql -u lcars -pNCC1701D ingenieria -e "SELECT * FROM alumnos;"
rm -f /var/www/html/index.html
cp /root/index.php /var/www/html/
systemctl restart apache2
mysql -e "SHOW DATABASES;"
mysql -u lcars -pNCC1701D ingenieria -e "SELECT * FROM alumnos;"
cat /etc/network/interfaces
ip route | grep default
nano /etc/network/interfaces
export TERM=xterm
nano /etc/network/interfaces
systemctl restart networking
ip a
cat /etc/network/interfaces
journalctl -xeu networking.service --no-pager | tail -25
reboot
ip a
poweroff
