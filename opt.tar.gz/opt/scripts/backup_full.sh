#!/bin/bash
#
# backup_full.sh - Respaldo de un directorio en .tar.gz con fecha ANSI (AAAAMMDD)
# Uso: backup_full.sh <origen> <destino>
#

# --- Opcion de ayuda ---
if [ "$1" = "-help" ] || [ "$1" = "-h" ] || [ $# -eq 0 ]; then
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "  <origen>   Directorio a respaldar      (ej: /var/log)"
    echo "  <destino>  Directorio donde se guarda  (ej: /backup_dir)"
    echo ""
    echo "El backup se genera como: <nombre>_bkp_AAAAMMDD.tar.gz"
    exit 0
fi

ORIGEN="$1"
DESTINO="$2"

# --- Validar que origen y destino esten disponibles ---
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi
if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino '$DESTINO' no existe o no esta disponible."
    exit 1
fi

# --- Nombre con fecha ANSI (AAAAMMDD) ---
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# --- Generar el backup ---
tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Backup creado correctamente: ${DESTINO}/${ARCHIVO}"
else
    echo "Error: fallo la creacion del backup."
    exit 1
fi
